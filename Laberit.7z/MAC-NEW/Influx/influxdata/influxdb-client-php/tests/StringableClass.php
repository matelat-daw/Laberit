<?php

namespace InfluxDB2Test;

class StringableClass
{
    public function __toString()
    {
        return "stringable";
    }
}
